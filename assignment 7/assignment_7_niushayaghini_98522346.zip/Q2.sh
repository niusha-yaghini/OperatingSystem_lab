#!/bin/bash

echo Enter the first number:
read num1

echo Enter the operation:
read op

echo Enter the second number:
read num2

case $op in
	"+")
		expr $num1 + $num2
		;;
	"-")
		expr $num1 - $num2
		;;
	"*")
		expr $num1 \* $num2
		;;
	"/")
		expr $num1 / $num2
		;;
	*)
		echo Wrong operation!
		;;
esac
